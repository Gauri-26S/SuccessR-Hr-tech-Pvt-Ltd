<?php
include_once('connection.php');

if(isset($_POST['register']))
{
    $name=$_POST['name'];
    $phone=$_POST['phone'];
    $username=$_POST['username'];
    $role=$_POST['role'];

    $sql   ="INSERT INTO `tbl_user`(`name`, `phone`, `username`, `role`) VALUES ('$name','$phone','$username','$role')";
    $result=mysqli_query($conn,$sql);
    if($result){ 
    header('location:../index.php');
    echo"<script>alert('Booking Success');</script>";   
    }else{
        die(mysqli_error($conn)) ;
    }
   
}
